# hiveRandom
Hive Random Data Generator based on input table schema
